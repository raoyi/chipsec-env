LzmaCompress is based on the LZMA SDK 18.05.  LZMA SDK 18.05
was placed in the public domain on 2018-04-30.  It was
released on the http://www.7-zip.org/sdk.html website.
