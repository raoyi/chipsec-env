It is based on the Brotli v1.0.6.
Brotli was released on the website https://github.com/google/brotli.
